import React from 'react';
import { Code2, UserCircle } from 'lucide-react';

interface HeaderProps {
  userName: string;
  userImage: string;
}

export default function Header({ userName, userImage }: HeaderProps) {
  return (
    <header className="bg-blue-600 text-white py-4 px-6 fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Code2 size={32} />
          <h1 className="text-2xl font-bold">HackHub</h1>
        </div>
        
        <div className="flex items-center space-x-6">
          <button className="bg-white text-blue-600 px-4 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
            Host a Hackathon
          </button>
          
          <div className="flex items-center space-x-3">
            <span className="font-medium">{userName}</span>
            {userImage ? (
              <img src={userImage} alt={userName} className="w-8 h-8 rounded-full" />
            ) : (
              <UserCircle size={32} />
            )}
          </div>
        </div>
      </div>
    </header>
  );
}