import React from 'react';
import { Calendar, Users, Trophy, MapPin } from 'lucide-react';
import { Hackathon } from '../types';

interface HackathonCardProps {
  hackathon: Hackathon;
}

export default function HackathonCard({ hackathon }: HackathonCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]">
      <img
        src={hackathon.image}
        alt={hackathon.name}
        className="w-full h-48 object-cover"
      />
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-1">{hackathon.name}</h3>
            <p className="text-gray-600">{hackathon.organization}</p>
          </div>
          <span className="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
            {hackathon.mode}
          </span>
        </div>
        
        <p className="text-gray-700 mb-4 line-clamp-2">{hackathon.description}</p>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center text-gray-600">
            <Calendar size={18} className="mr-2" />
            <span>{hackathon.duration}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Users size={18} className="mr-2" />
            <span>{hackathon.teamSize}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Trophy size={18} className="mr-2" />
            <span>{hackathon.prizePool}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <MapPin size={18} className="mr-2" />
            <span>{hackathon.theme}</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            {hackathon.registeredCount} teams registered
          </div>
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
            Register Now
          </button>
        </div>
      </div>
    </div>
  );
}