export interface Hackathon {
  id: string;
  name: string;
  organization: string;
  duration: string;
  mode: 'Online' | 'In-Person' | 'Hybrid';
  prizePool: string;
  theme: string;
  image: string;
  registrationDeadline: string;
  teamSize: string;
  registeredCount: number;
  description: string;
}

export type FilterOptions = {
  mode: string;
  theme: string;
  duration: string;
}