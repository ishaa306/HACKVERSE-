import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import HackathonCard from './components/HackathonCard';
import { hackathons } from './data';
import { FilterOptions } from './types';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterOptions>({
    mode: '',
    theme: '',
    duration: ''
  });

  const filteredHackathons = useMemo(() => {
    return hackathons.filter(hackathon => {
      const matchesSearch = hackathon.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          hackathon.organization.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          hackathon.theme.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesMode = !filters.mode || hackathon.mode === filters.mode;
      const matchesTheme = !filters.theme || hackathon.theme === filters.theme;
      const matchesDuration = !filters.duration || hackathon.duration === filters.duration;
      
      return matchesSearch && matchesMode && matchesTheme && matchesDuration;
    });
  }, [searchQuery, filters]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        userName="John Doe"
        userImage="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100"
      />
      
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-12">
        <div className="mb-8">
          <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            filters={filters}
            setFilters={setFilters}
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHackathons.map(hackathon => (
            <HackathonCard key={hackathon.id} hackathon={hackathon} />
          ))}
        </div>
        
        {filteredHackathons.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No hackathons found matching your criteria.</p>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;