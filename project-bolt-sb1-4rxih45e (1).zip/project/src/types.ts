export interface Judge {
  id: string;
  name: string;
  image: string;
  role: string;
}

export interface Team {
  id: string;
  teamNumber: number;
  teamName: string;
  problemStatement: string;
  githubLink: string;
  pptLink: string;
  videoLink: string;
  scores: {
    innovation: number;
    technical: number;
    presentation: number;
    feasibility: number;
    impact: number;
  };
  feedback: string;
}

export interface Hackathon {
  id: string;
  name: string;
  date: string;
  venue: string;
  organizer: string;
  theme: string;
  judges: Judge[];
}