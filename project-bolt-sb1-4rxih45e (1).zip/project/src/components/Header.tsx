import React from 'react';
import { Code2, LogOut } from 'lucide-react';
import { Judge } from '../types';

interface HeaderProps {
  currentJudge: Judge;
  onSignOut: () => void;
}

export default function Header({ currentJudge, onSignOut }: HeaderProps) {
  return (
    <header className="bg-blue-600 text-white py-4 px-6 fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Code2 size={32} />
          <h1 className="text-2xl font-bold">HackerVerse</h1>
        </div>
        
        <div className="flex items-center space-x-8">
          <span className="bg-blue-500 px-4 py-1 rounded-full text-sm font-medium">
            You are a Judge
          </span>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <span className="font-medium">{currentJudge.name}</span>
              <img 
                src={currentJudge.image} 
                alt={currentJudge.name} 
                className="w-8 h-8 rounded-full"
              />
            </div>
            
            <button
              onClick={onSignOut}
              className="flex items-center space-x-2 hover:text-blue-200 transition-colors"
            >
              <LogOut size={20} />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}