import React from 'react';
import { ExternalLink, Github, FileText, Video, MessageSquare } from 'lucide-react';
import { Team } from '../types';

interface ScoringTableProps {
  teams: Team[];
  onScoreChange: (teamId: string, criterion: string, value: number) => void;
  onFeedbackChange: (teamId: string, feedback: string) => void;
  onSubmit: () => void;
}

export default function ScoringTable({ teams, onScoreChange, onFeedbackChange, onSubmit }: ScoringTableProps) {
  const criteria = [
    { key: 'innovation', label: 'Innovation' },
    { key: 'technical', label: 'Technical Complexity' },
    { key: 'presentation', label: 'Presentation' },
    { key: 'feasibility', label: 'Feasibility' },
    { key: 'impact', label: 'Impact' }
  ];

  const calculateTotal = (scores: Team['scores']) => {
    return Object.values(scores).reduce((sum, score) => sum + score, 0);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Team</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Problem Statement</th>
              {criteria.map(({ label }) => (
                <th key={label} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {label} (0-10)
                </th>
              ))}
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Links</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Feedback</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total /50</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {teams.map((team) => (
              <tr key={team.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="font-medium text-gray-900">#{team.teamNumber}</div>
                    <div className="text-gray-500">{team.teamName}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <p className="text-gray-900 max-w-md">{team.problemStatement}</p>
                </td>
                {criteria.map(({ key }) => (
                  <td key={key} className="px-6 py-4">
                    <input
                      type="number"
                      min="0"
                      max="10"
                      value={team.scores[key as keyof Team['scores']]}
                      onChange={(e) => onScoreChange(team.id, key, Number(e.target.value))}
                      className="w-16 px-2 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </td>
                ))}
                <td className="px-6 py-4">
                  <div className="flex space-x-2">
                    <a
                      href={team.githubLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Github size={20} />
                    </a>
                    <a
                      href={team.pptLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <FileText size={20} />
                    </a>
                    <a
                      href={team.videoLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Video size={20} />
                    </a>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <textarea
                    value={team.feedback}
                    onChange={(e) => onFeedbackChange(team.id, e.target.value)}
                    placeholder="Enter feedback..."
                    className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={2}
                  />
                </td>
                <td className="px-6 py-4 text-center font-medium text-lg">
                  {calculateTotal(team.scores)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="px-6 py-4 bg-gray-50">
        <button
          onClick={onSubmit}
          className="w-full md:w-auto px-6 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
        >
          Submit Scores
        </button>
      </div>
    </div>
  );
}