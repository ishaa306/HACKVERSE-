import React, { useState } from 'react';
import Header from './components/Header';
import HackathonInfo from './components/HackathonInfo';
import ScoringTable from './components/ScoringTable';
import { currentHackathon, teams as initialTeams } from './data';
import { Team } from './types';

function App() {
  const [teams, setTeams] = useState<Team[]>(initialTeams);

  const handleScoreChange = (teamId: string, criterion: string, value: number) => {
    setTeams(teams.map(team => {
      if (team.id === teamId) {
        return {
          ...team,
          scores: {
            ...team.scores,
            [criterion]: value
          }
        };
      }
      return team;
    }));
  };

  const handleFeedbackChange = (teamId: string, feedback: string) => {
    setTeams(teams.map(team => {
      if (team.id === teamId) {
        return {
          ...team,
          feedback
        };
      }
      return team;
    }));
  };

  const handleSubmit = () => {
    // Here you would typically send the scores to a backend
    console.log('Submitting scores:', teams);
    alert('Scores submitted successfully!');
  };

  const handleSignOut = () => {
    // Handle sign out logic here
    console.log('Signing out...');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentJudge={currentHackathon.judges[0]}
        onSignOut={handleSignOut}
      />
      
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-12">
        <div className="mb-8">
          <HackathonInfo hackathon={currentHackathon} />
        </div>
        
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Team Scoring</h2>
          <ScoringTable
            teams={teams}
            onScoreChange={handleScoreChange}
            onFeedbackChange={handleFeedbackChange}
            onSubmit={handleSubmit}
          />
        </div>
      </main>
    </div>
  );
}

export default App;