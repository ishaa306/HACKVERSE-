import express from 'express';
import cors from 'cors';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Email transporter setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Registration endpoint
app.post('/api/register', async (req, res) => {
  try {
    const {
      teamName,
      leaderName,
      leaderEmail,
      members,
      githubLink,
      pptLink,
      videoLink,
      problemStatement,
      hackathonId,
      hackathonName
    } = req.body;

    // Send confirmation email
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: leaderEmail,
      subject: `Registration Confirmed - ${hackathonName}`,
      html: `
        <h1>Registration Confirmation</h1>
        <p>Dear ${leaderName},</p>
        <p>Your team has been successfully registered for ${hackathonName}.</p>
        <h2>Registration Details:</h2>
        <ul>
          <li>Team Name: ${teamName}</li>
          <li>Team Members: ${members.join(', ')}</li>
          <li>Problem Statement: ${problemStatement}</li>
          <li>GitHub Repository: ${githubLink}</li>
          <li>Presentation Link: ${pptLink}</li>
          <li>Video Demo Link: ${videoLink}</li>
        </ul>
        <p>Good luck!</p>
      `
    });

    res.json({ success: true, message: 'Registration successful' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ success: false, message: 'Registration failed' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});