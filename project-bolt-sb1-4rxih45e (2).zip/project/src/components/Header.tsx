import React from 'react';
import { Code2, Plus, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { User } from '../types';

interface HeaderProps {
  user: User;
  onSignOut?: () => void;
  showHostButton?: boolean;
}

export default function Header({ user, onSignOut, showHostButton = false }: HeaderProps) {
  return (
    <header className="bg-blue-600 text-white py-4 px-6 fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-3">
          <Code2 size={32} />
          <h1 className="text-2xl font-bold">HackerVerse</h1>
        </Link>
        
        <div className="flex items-center space-x-6">
          {showHostButton && (
            <Link
              to="/host"
              className="flex items-center space-x-2 bg-white text-blue-600 px-4 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              <Plus size={20} />
              <span>Host a Hackathon</span>
            </Link>
          )}
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <span className="font-medium">{user.name}</span>
              <img 
                src={user.image} 
                alt={user.name} 
                className="w-8 h-8 rounded-full"
              />
            </div>
            
            {onSignOut && (
              <button
                onClick={onSignOut}
                className="flex items-center space-x-2 hover:text-blue-200 transition-colors"
              >
                <LogOut size={20} />
                <span>Sign Out</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}