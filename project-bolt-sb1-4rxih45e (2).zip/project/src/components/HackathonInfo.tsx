import React from 'react';
import { Calendar, MapPin, Users } from 'lucide-react';
import { Hackathon } from '../types';

interface HackathonInfoProps {
  hackathon: Hackathon;
}

export default function HackathonInfo({ hackathon }: HackathonInfoProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">{hackathon.name}</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="flex items-center text-gray-600">
          <Calendar size={20} className="mr-2" />
          <span>{hackathon.date}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <MapPin size={20} className="mr-2" />
          <span>{hackathon.venue}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Users size={20} className="mr-2" />
          <span>{hackathon.organizer}</span>
        </div>
      </div>
      
      <div className="border-t pt-4">
        <h3 className="text-lg font-semibold mb-3">Theme</h3>
        <p className="text-gray-700">{hackathon.theme}</p>
      </div>
      
      <div className="border-t mt-4 pt-4">
        <h3 className="text-lg font-semibold mb-3">Judges Panel</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {hackathon.judges.map(judge => (
            <div key={judge.id} className="flex items-center space-x-3">
              <img
                src={judge.image}
                alt={judge.name}
                className="w-10 h-10 rounded-full"
              />
              <div>
                <p className="font-medium text-gray-900">{judge.name}</p>
                <p className="text-sm text-gray-500">{judge.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}