import { Hackathon, Team } from './types';

export const currentHackathon: Hackathon = {
  id: '1',
  name: 'TechInnovate 2025',
  date: 'March 15-16, 2025',
  venue: 'Virtual Event',
  organizer: 'Microsoft',
  theme: 'AI/ML Solutions for Healthcare',
  judges: [
    {
      id: '1',
      name: 'Dr. Sarah Chen',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100',
      role: 'Lead Judge'
    },
    {
      id: '2',
      name: 'Prof. James Wilson',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100',
      role: 'Technical Judge'
    },
    {
      id: '3',
      name: 'Dr. Emily Rodriguez',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=100',
      role: 'Domain Expert'
    }
  ]
};

export const teams: Team[] = [
  {
    id: '1',
    teamNumber: 1,
    teamName: 'HealthAI Pro',
    problemStatement: 'AI-powered early disease detection system using medical imaging',
    githubLink: 'https://github.com/healthai-pro/disease-detection',
    pptLink: 'https://drive.google.com/healthai-presentation',
    videoLink: 'https://youtube.com/healthai-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '2',
    teamNumber: 2,
    teamName: 'MedTech Innovators',
    problemStatement: 'Smart patient monitoring system using IoT and ML',
    githubLink: 'https://github.com/medtech/patient-monitor',
    pptLink: 'https://drive.google.com/medtech-presentation',
    videoLink: 'https://youtube.com/medtech-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '3',
    teamNumber: 3,
    teamName: 'DataCare Solutions',
    problemStatement: 'Predictive analytics for hospital resource management',
    githubLink: 'https://github.com/datacare/hospital-analytics',
    pptLink: 'https://drive.google.com/datacare-presentation',
    videoLink: 'https://youtube.com/datacare-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '4',
    teamNumber: 4,
    teamName: 'Neural Health',
    problemStatement: 'Mental health prediction using social media analysis',
    githubLink: 'https://github.com/neural/mental-health',
    pptLink: 'https://drive.google.com/neural-presentation',
    videoLink: 'https://youtube.com/neural-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '5',
    teamNumber: 5,
    teamName: 'BioTech Vision',
    problemStatement: 'Automated medical report generation using NLP',
    githubLink: 'https://github.com/biotech/report-gen',
    pptLink: 'https://drive.google.com/biotech-presentation',
    videoLink: 'https://youtube.com/biotech-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '6',
    teamNumber: 6,
    teamName: 'Health Pioneers',
    problemStatement: 'AI-driven drug discovery platform',
    githubLink: 'https://github.com/pioneers/drug-discovery',
    pptLink: 'https://drive.google.com/pioneers-presentation',
    videoLink: 'https://youtube.com/pioneers-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '7',
    teamNumber: 7,
    teamName: 'MedAI Labs',
    problemStatement: 'Personalized treatment recommendation system',
    githubLink: 'https://github.com/medai/treatment-rec',
    pptLink: 'https://drive.google.com/medai-presentation',
    videoLink: 'https://youtube.com/medai-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '8',
    teamNumber: 8,
    teamName: 'Smart Diagnostics',
    problemStatement: 'Real-time disease outbreak prediction system',
    githubLink: 'https://github.com/smartdiag/outbreak-pred',
    pptLink: 'https://drive.google.com/smartdiag-presentation',
    videoLink: 'https://youtube.com/smartdiag-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '9',
    teamNumber: 9,
    teamName: 'Health Analytics',
    problemStatement: 'Healthcare workflow optimization using ML',
    githubLink: 'https://github.com/healthanalytics/workflow-opt',
    pptLink: 'https://drive.google.com/healthanalytics-presentation',
    videoLink: 'https://youtube.com/healthanalytics-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  },
  {
    id: '10',
    teamNumber: 10,
    teamName: 'ML Medics',
    problemStatement: 'AI-powered medical image segmentation',
    githubLink: 'https://github.com/mlmedics/image-seg',
    pptLink: 'https://drive.google.com/mlmedics-presentation',
    videoLink: 'https://youtube.com/mlmedics-demo',
    scores: { innovation: 0, technical: 0, presentation: 0, feasibility: 0, impact: 0 },
    feedback: ''
  }
];