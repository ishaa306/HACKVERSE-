export interface User {
  id: string;
  name: string;
  email: string;
  image: string;
}

export interface Hackathon {
  id: string;
  name: string;
  organization: string;
  description: string;
  image: string;
  duration: string;
  mode: 'Online' | 'In-Person' | 'Hybrid';
  prizePool: string;
  theme: string;
  teamSize: string;
  registeredCount: number;
  deadline: string;
  problemStatements?: string[];
  venue?: string;
  startDate: string;
  endDate: string;
}

export interface Team {
  id: string;
  hackathonId: string;
  teamName: string;
  leaderName: string;
  leaderEmail: string;
  members: string[];
  githubLink: string;
  pptLink: string;
  videoLink: string;
  problemStatement: string;
}

export interface FilterOptions {
  mode: string;
  theme: string;
  duration: string;
}