import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Calendar, Users, Trophy, MapPin, AlertCircle } from 'lucide-react';
import Header from '../components/Header';
import ChatBot from '../components/ChatBot';
import { hackathons } from '../data/hackathons';
import { Hackathon } from '../types';

const mockUser = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
  image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100'
};

export default function RegistrationPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const hackathon = hackathons.find(h => h.id === id);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    teamName: '',
    leaderName: '',
    leaderEmail: '',
    members: [''],
    githubLink: '',
    pptLink: '',
    videoLink: '',
    problemStatement: '',
    lookingForMembers: false
  });

  useEffect(() => {
    if (!hackathon) {
      navigate('/');
    }
  }, [hackathon, navigate]);

  if (!hackathon) return null;

  const maxTeamSize = parseInt(hackathon.teamSize.split('-')[1]);

  const handleAddMember = () => {
    if (formData.members.length < maxTeamSize - 1) {
      setFormData({ ...formData, members: [...formData.members, ''] });
    }
  };

  const handleMemberChange = (index: number, value: string) => {
    const newMembers = [...formData.members];
    newMembers[index] = value;
    setFormData({ ...formData, members: newMembers });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Here you would typically send the data to your backend
      console.log('Submitting registration:', formData);
      
      // Show success message
      setShowSuccess(true);
      
      // Redirect after 3 seconds
      setTimeout(() => {
        navigate('/');
      }, 3000);
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={mockUser} />
      
      <main className="max-w-7xl mx-auto px-6 pt-24 pb-12">
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{hackathon.name}</h1>
          <p className="text-gray-600 mb-6">{hackathon.description}</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
            <div className="flex items-center text-gray-600">
              <Calendar size={20} className="mr-2" />
              <span>{hackathon.duration}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Users size={20} className="mr-2" />
              <span>{hackathon.teamSize}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <Trophy size={20} className="mr-2" />
              <span>{hackathon.prizePool}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin size={20} className="mr-2" />
              <span>{hackathon.mode}</span>
            </div>
          </div>
          
          {hackathon.venue && (
            <div className="bg-blue-50 p-4 rounded-lg mb-6">
              <p className="text-blue-800">Venue: {hackathon.venue}</p>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Registration Form</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Team Name
              </label>
              <input
                type="text"
                required
                value={formData.teamName}
                onChange={(e) => setFormData({ ...formData, teamName: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Team Leader Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.leaderName}
                  onChange={(e) => setFormData({ ...formData, leaderName: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Team Leader Email
                </label>
                <input
                  type="email"
                  required
                  value={formData.leaderEmail}
                  onChange={(e) => setFormData({ ...formData, leaderEmail: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Team Members
              </label>
              {formData.members.map((member, index) => (
                <input
                  key={index}
                  type="text"
                  placeholder={`Team Member ${index + 1}`}
                  value={member}
                  onChange={(e) => handleMemberChange(index, e.target.value)}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                />
              ))}
              {formData.members.length < maxTeamSize - 1 && (
                <button
                  type="button"
                  onClick={handleAddMember}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  + Add Team Member
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  GitHub Repository Link
                </label>
                <input
                  type="url"
                  required
                  value={formData.githubLink}
                  onChange={(e) => setFormData({ ...formData, githubLink: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Presentation Link (Google Drive)
                </label>
                <input
                  type="url"
                  required
                  value={formData.pptLink}
                  onChange={(e) => setFormData({ ...formData, pptLink: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Video Demo Link (YouTube)
                </label>
                <input
                  type="url"
                  required
                  value={formData.videoLink}
                  onChange={(e) => setFormData({ ...formData, videoLink: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            
            {hackathon.problemStatements ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Choose Problem Statement
                </label>
                <select
                  required
                  value={formData.problemStatement}
                  onChange={(e) => setFormData({ ...formData, problemStatement: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select a problem statement</option>
                  {hackathon.problemStatements.map((statement, index) => (
                    <option key={index} value={statement}>
                      {statement}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Problem Statement
                </label>
                <textarea
                  required
                  value={formData.problemStatement}
                  onChange={(e) => setFormData({ ...formData, problemStatement: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={4}
                />
              </div>
            )}
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="lookingForMembers"
                checked={formData.lookingForMembers}
                onChange={(e) => setFormData({ ...formData, lookingForMembers: e.target.checked })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="lookingForMembers" className="ml-2 block text-sm text-gray-700">
                Looking for team members
              </label>
            </div>
          </div>
          
          <div className="mt-8">
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Submit Registration
            </button>
          </div>
        </form>
        
        {showSuccess && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white p-6 rounded-lg shadow-xl">
              <div className="flex items-center text-green-600 mb-4">
                <AlertCircle size={24} className="mr-2" />
                <h3 className="text-lg font-semibold">Registration Successful!</h3>
              </div>
              <p className="text-gray-600">
                A confirmation email has been sent to your email address.
                Redirecting to homepage...
              </p>
            </div>
          </div>
        )}
      </main>
      
      <ChatBot hackathon={hackathon} />
    </div>
  );
}